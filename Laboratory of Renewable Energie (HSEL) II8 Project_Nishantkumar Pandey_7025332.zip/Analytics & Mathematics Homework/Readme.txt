Student 1:Laukik Patil
	  Matrikel-No.:7025305

Student 2:Nishantkumar Pandey
	Matrikel-No.:7025332


Topic: Processing and Analyzing GRIB2 Weather Data from the German Weather Service DWD 


File tree:
Analytics & Mathematics Homework
├───Presentation
├───Reference
└───Report
│   ├───General
│   ├───img
│   └───src

